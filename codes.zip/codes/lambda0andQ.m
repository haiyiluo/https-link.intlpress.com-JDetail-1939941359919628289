% Define parameters
pi_value = pi;
rouw = 1000;
rouc = 1500;
phi = rouw / rouc;
Rb = 0.0006;
eta = 1.1E-3;
Vb = 4 * pi_value * Rb^3 / 3;
Rc = 0.005;
S_initial = 4 * pi_value * Rc^2;
V = 4 * pi_value * Rc^3 / 3;
m = 6E-4;
n = (m / rouw - V) / Vb;
g = 9.81;

% Initial guesses for lambda0, q, and S0
lambda0_initial = 5.86E-5;
q_initial = 1;
S0_initial = 1.66;

% Time span and initial conditions
tspan = 0:0.001:20;

% Load the data from Excel
data = readtable('upTvst.xlsx');

% Extract t and Varname3
t = data{:, 1};
Varname3 = data{:, 2}; % Assuming Varname3 is the second column

% Remove rows with NaN values
validData = ~isnan(t) & ~isnan(Varname3);
t = t(validData);
Varname3 = Varname3(validData);

% Define S and Sdot functions
Tr = 7.231; % Calculated parameter
Smc = 0.02;
S = @(t, q, S0) Smc + (S0 - Smc) .* exp(-t / Tr) ./ (1 + (q * Tr * (S0 - Smc)) * (1 - exp(-t / Tr)));

% Calculate Lambda
Rate = n ./ (S_initial .* Varname3);
Lambda = Rate .* (Vb * g);

% Plot Lambda as a function of t
figure;
plot(t, Lambda, 'o', 'DisplayName', 'Lambda vs t');
xlabel('t');
ylabel('Lambda');
title('Lambda as a function of t');
hold on;

% Define the custom fit type with lambda0, q, and S0 as coefficients
ft = fittype(@(lambda0, q, S0, t) lambda0 * ((S(t, q, S0))./S0).^1.5, ...
             'independent', 't', 'dependent', 'Lambda');

% Set initial guesses for lambda0, q, and S0
opts = fitoptions('Method', 'NonlinearLeastSquares');
opts.StartPoint = [lambda0_initial, q_initial, S0_initial];
opts.Lower = [0, 0, 0]; % Ensure lambda0, q, and S0 are non-negative

% Fit the model to data
[fitresult, gof] = fit(t, Lambda, ft, opts);

% Extract coefficients from the fit result
coeffs = coeffvalues(fitresult);
lambda0_fit = coeffs(1);
q_fit = coeffs(2);
S0_fit = coeffs(3);

% Generate fitted values for plotting
fitted_Lambda = feval(fitresult, t);

% Plot the fitted curve
plot(t, fitted_Lambda, 'r-', 'DisplayName', 'Fitted Curve');
legend('show');

% Create a string representing the fitted equation
equationStr = sprintf('Lambda = %.2f * (S(t, %.2f, %.2f)/%.2f)^{1.5}', lambda0_fit, q_fit, S0_fit);

% Display the fitted equation and parameters on the plot
text(0.1, 0.9, equationStr, 'Units', 'normalized', 'FontSize', 10, 'Color', 'r', 'BackgroundColor', 'w');

disp(['Fitted lambda0: ', num2str(lambda0_fit)]);
disp(['Fitted q: ', num2str(q_fit)]);
disp(['Fitted S0: ', num2str(S0_fit)]);
