clc;
clear;
close all;

% 定义常量
Mc = 0.001; % 巧克力的重量，KG
Rc = 0.005; % 一个巧克力的半径
Rb = 0.0005;
theta0 = 70*pi/180; % 第一个气泡破裂的角度
thetab = 0.06*pi/180; % 一个气泡所占角度
Sb = Rb^2; % 一个气泡的占地面积
Ic = (2/5) * Mc * Rc^2; % 巧克力转动惯量
s = 1; % 假设一个常数s
n = 100; % 气泡带的宽度
rouc = 1.2; % 巧克力浓度
rouw = 1.1; % 水的密度
% S0 = 1.66;
% Smc = 0.002;
Tr = 2172; % 36.2min=这么多秒
% chi = 2.5; 
% lambda0 = 58.4;
Vb = 4*pi*Rb^3/3;
g = 9.81;
Fb = Vb * g; % 一个泡泡的力，N
Tb1 = -Fb * cos(theta0) * Rc*5; % 第一个气泡的力矩（微扰大概的大小）
phi = rouw / rouc;
eta = 1.1E-3;%粘滞系数
max = 4*pi*Rc^2/Sb;
Stot = 4*pi*Rc^2;
m=0.0012;
% 将参数封装到结构体中
params.Tb1 = Tb1;
params.Ic = Ic;
params.Fb = Fb;
params.thetab = thetab;
params.Sb = Sb;
params.s = s;
params.theta0 = theta0;
params.n = n;
params.Rc = Rc;
params.Rb = Rb;
params.rouc = rouc;
params.rouw = rouw;
params.g = g;
params.phi = phi;
params.eta = eta;
params.Vb = Vb;
params.Nthresh = 84;
params.max = max;
params.Stot = Stot;
params.m = m;

% 定义初始条件
tspan = 0:0.01:30;  % 初始时间范围
Theta0 = [0; 0; 0; -0.09; 0.01; 0; 0; 0.1; 0; 0;0]; 
% 1.Nbreak带来的theta break
% 2.Nbreak带来的角速度
%Theta3是Nnew
%Theta4是高度
%Theta5是速度，竖直方向向下为正
%6是Nnew的角度，
%7是New的速度
%Theta8是总的转动角度
%theta9是Nbreak
%Theta10 是Sa
%Theta11是总的破裂量



% 定义 Rt 函数
Rt = @(t) 2.309E5 * exp(-0.01617 * t);
Rt_integral = cumtrapz(tspan, Rt(tspan)); % 计算Rt从0到t的积分

   

% 检查是否有足够的数据进行绘图
% 设置绝对和相对求解精度
options = odeset('RelTol', 1e-9, 'AbsTol', 1e-12); 
% 使用 ode45 求解微分方程
 [t, Theta] = ode45(@(t, Theta) f(t, Theta, params),tspan, Theta0, options);


%%
    % 绘图
    
    figure;
    % for i = 1:8
    % subplot(4, 3, i);
    % plot(tspan(1:1000), Theta(1:1000,i), 'LineWidth', 2, 'DisplayName', 'Nnet');
    % xlabel('Time (s)');
    % ylabel('Nnet (个)');
    % title('Nnet vs. Time');
    % legend;
    % grid on;
    % hold on;
    % subplot (4,3,9);
    % plot(tspan(1:1000), Theta(1:1000,11), 'LineWidth', 2, 'DisplayName', 'Nnet');
    % xlabel('Time (s)');
    % ylabel('Nnet (个)');
    % %xlim([0, 1]);
    % 
    % end
    subplot(2,1,1);
    plot(tspan(1:1000), Theta(1:1000,4), 'LineWidth', 2, 'DisplayName', '高度');
    hold on;
    subplot (2,1,2);
    plot(tspan(1:1000), Theta(1:1000,11), 'LineWidth', 2, 'DisplayName', '总破裂量');


function dThdt = f(t, Theta, params)
    Tb1 = params.Tb1;
    Ic = params.Ic;
    Fb = params.Fb;
    thetab = params.thetab;
    Sb = params.Sb;
    Rc = params.Rc;
    Rb = params.Rb;
    n = params.n;
    s = params.s; % 使用 params.s 传递的 s 变量
    phi = params.phi;
    Stot = params.Stot;
    eta = params.eta;
    g = params.g;
    Vb = params.Vb;
    rouc = params.rouc;
    max = params.max;
    m=params.m;
%% 将Rt_integral1转换为t的函数

%方式2
%瞬时气泡个数
Rt =  2.309E5 * exp(-0.001617 * t);
Rt_integral1 = ((-(2.309E5/0.001617)*exp(-0.001617 * t))-(-(2.309E5/0.001617)*exp(-0.001617 * 0)));


    dThdt = zeros(11, 1); %初始化
   %% 转动
    %Theta1对应Nbreak产生的角位移，Theta2对应其角速度
    %如果浸没物已经在液体顶端（-0.09m,取向下为正），才以转动的公式计算它，否则设其为0，因为这是转动不会导致气泡破裂
      dThdt(1) = Theta(2);
    
    %Theta4是竖直方向高度
    if Theta(4) >= -0.09 %&& Theta(8)<=0
        dThdt(2) = Tb1 .* n ./ Ic + Fb .* n *Rc./ Ic * (sin((Theta(8) + thetab) ./ 2) * sin(Theta(8) ./ 2) ./ sin(thetab ./ 2));
    else
        dThdt(1) = 0;
        dThdt(2)=0;
        Theta(8)=0;%总的转动角度归零
        dThdt(9)=0; %Nbreak设为0
    end
    
    %theta9是Nbreak
    dThdt(9)=mod(dThdt(1),360)/thetab*n;
    %Theta10是dSa
    dThdt(10)= (Stot+Theta(9)*Sb)/(1+Rt)/Stot;
    Sa =Theta(10);
    %Theta3是Nnew
    dThdt(3) =   Rt.* Sa;
    %Theta11是总的破裂量
    dThdt(11)= (dThdt(9)-dThdt(3))*Stot;
    Theta(11);
    %Nt是总的气泡数量
    Nt = 4*pi*Rc^2/Sb - Theta(11); 
    if Nt>max
        dThdt(3)=0;
        dThdt(10)=0; %可生成气泡的面积设为0
    end
    if Nt<0
        dThdt(9)=0;%Nbreak变化率设为0
        dThdt(1)=0;
        dThdt(10)=0;
        
    end
        
    %6是Nnew的角度，7是New的速度
    dThdt(6)=Theta(7);
    dThdt(7)=squeeze(Fb*Rc / Ic * n * (-cosd(-thetab / 2 * (Rt_integral1 .* (Sb * (Theta(1) ./ Ic) ./ (1 + Rt_integral1 * Sb)))) - thetab + Theta(8)) ./ ...
               (2 * sind(-thetab ./ s)));
    %Theta8是总的转动角度
    dThdt(8)=dThdt(1)+dThdt(6);
    Theta(11)
    %% 平动
    %Theta4是高度
    %Theta5是速度，竖直方向向下为正
    dThdt(4) = Theta(5);  
   
   
    % if Theta(4)<-0.09 && Theta(11)<1056 %dThdt(5)<=0 %物体漂浮，有足够足够加速度支撑浮力
    %      dThdt(4)=0;
    % end
    % if Theta(4) >=0 && Theta(11)>=1056 %Theta(4)>=0 %物体沉底，但没足够加速度浮起
    %     dThdt(4)=0;
    % end
    % 

    if dThdt(5) >=0 && Theta(4)>=0 %物体沉底，但没足够加速度浮起
        dThdt(5)=0;
    elseif Theta(4)<-0.09 && dThdt(5)<=0 %物体漂浮，有足够足够加速度支撑浮力
         dThdt(5)=0; 
    else
         dThdt(5) =  (m-((4*Rc^3*pi/3)+Rt_integral1*Vb*Stot)*1000)*g/m;
    end




end

