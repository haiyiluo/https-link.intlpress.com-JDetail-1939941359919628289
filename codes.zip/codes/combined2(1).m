clc;
clear;
close all;

% 定义常量
Mc = 0.001; % 巧克力的重量，KG
Rc = 0.005; % 一个巧克力的半径
Rb = 0.0005;
theta0 = 0.1; % 第一个气泡破裂的角度
thetab = 0.06; % 一个气泡所占角度
Sb = Rb^2; % 一个气泡的占地面积
Ic = (2/5) * Mc * Rc^2; % 巧克力转动惯量
s = 1; % 假设一个常数s
n = 4; % 气泡带的宽度
rouc = 1.2; % 巧克力浓度
rouw = 1; % 水的密度
S0 = 1.66;
Smc = 0.002;
Tr = 2172; % 36.2min=这么多秒
chi = 2.5;
lambda0 = 58.4;
Vb = 4*pi*Rb^3/3;
g = 9.81;
Fb = Vb * g; % 一个泡泡的力，N
Tb1 = -Fb * cosd(theta0) * Rc; % 第一个气泡的力矩
phi = rouw / rouc;
eta = 1.1E-3;

% 将参数封装到结构体中
params.Tb1 = Tb1;
params.Ic = Ic;
params.Fb = Fb;
params.thetab = thetab;
params.Sb = Sb;
params.s = s;
params.theta0 = theta0;
params.n = n;
params.Rc = Rc;
params.rouc = rouc;
params.rouw = rouw;
params.g = g;
params.phi = phi;
params.eta = eta;
params.Vb = Vb;
params.Nthresh = 84;

% 定义初始条件
tspan = [0, 100];  % 初始时间范围
y0 = [0; 0]; % 初始化 y 的初值
Theta0 = [0; 0; 0; 0; 100; 1; 0]; % 初始条件：Theta(1)到Theta(6)都初始化为0

tcurrent = tspan(1);
tend = tspan(2);

recordY = [];
Theta_recorded = [];
time_record = [];

continueIntegration = false;

% 定义 Rt 函数
Rt = @(t) 2.309E5 * exp(-0.001617 * t);

% 初始化 Theta 和 Nnet 变量
Theta = Theta0;
Nnet = [];

while tcurrent < tend
    if continueIntegration
        % 设置求解器选项，添加事件检测
        options_gg = odeset('RelTol', 1e-9, 'AbsTol', 1e-12, 'Events', @(t, y) event_y_reaches_threshold(t, y));
        
        % 求解 y 的微分方程
        [t_y, y, te, ye, ~] = ode45(@(t, y) gg(t, y, params, Rt, Theta), [tcurrent tend], y0, options_gg);
        
        if ~isempty(te)
            tcurrent = te(end);
        else
            tcurrent = tend;
        end
        
        recordY = [recordY; y];
        Theta_recorded = [Theta_recorded; Theta];
        time_record = [time_record; t_y];
        
        y0 = y(end, :);
        
        if y(end, 1) <= -0.09
            continueIntegration = false;
        end
    else
        % 检查是否满足重新开始的条件
        if Theta(7) < (1 - phi) * Rc / (3 * phi * Vb)
            continueIntegration = true;
        end
        tcurrent = tcurrent + 0.01;
    end
    
    % 更新 Theta
    Rt_integral = integral(@(t_var) Rt(t_var), 0, tcurrent);
    Theta = Theta + 0.01 * f(tcurrent, Theta, params, Rt_integral, y0);
    
    if y0(1) > -0.09
        continueIntegration = true;
    end
end

% 检查是否有足够的数据进行绘图
if ~isempty(Theta_recorded) && size(Theta_recorded, 2) >= 5 && ~isempty(time_record)
    % 绘图
    figure;
    subplot(2, 1, 1);
    plot(time_record, Theta_recorded(:, 5), 'LineWidth', 2, 'DisplayName', 'Nnet');
    xlabel('Time (s)');
    ylabel('Nnet (个)');
    title('Nnet vs. Time');
    legend;
    grid on;
    xlim([0, 100]);
    
    subplot(2, 1, 2);
    plot(time_record, recordY(:, 1), 'LineWidth', 2, 'DisplayName', 'y');
    xlabel('Time (s)');
    ylabel('y (m)');
    title('y vs. Time');
    legend;
    grid on;
else
    disp('没有足够的数据进行绘图');
end

% 事件函数：检测 y(1) 何时达到 -0.09
function [value, isterminal, direction] = event_y_reaches_threshold(~, y)
    value = y(1) + 0.09;  % 事件条件
    isterminal = 1;       % 事件发生时停止
    direction = -1;       % 检测下降的方向
end

% Theta 方程的微分方程
function dThdt = f(~, Theta, params, Rt_integral, y)
    Tb1 = params.Tb1;
    Ic = params.Ic;
    Fb = params.Fb;
    thetab = params.thetab;
    Sb = params.Sb;
    Rc = params.Rc;
    n = params.n;
    s = params.s; % 使用 params.s 传递的 s 变量

    dThdt = zeros(7, 1); 
    dThdt(1) = Theta(2);
    
    if y(1) <= -0.09
        Theta(2) = 0;
    else
        dThdt(2) = Tb1 * n / Ic + Fb * n / Ic * (sind((Theta(5) + thetab) / 2) * sind(Theta(5) / 2) / sind(thetab / 2));
    end
    
    dThdt(3) = Theta(4); 
    dThdt(4) = Fb / Ic * n * (-cosd(-thetab / 2 * (Rt_integral .* (Sb * (Theta(1) / Ic) / (1 + Rt_integral * Sb)))) - thetab + Theta(5)) / ...
               (2 * sind(-thetab / s)); % 此处使用 s 变量
    
    dThdt(5) = Theta(6); 
    dThdt(7) = Theta(5) / thetab * (1 - Rt_integral * Sb / thetab / (1 + Rt_integral * Sb));
    
    if Theta(7) < 0
        dThdt(6) = 0; % 气泡已经布满了
    else
        dThdt(6) = dThdt(2) + dThdt(4);
    end
end

% y 方程的微分方程
function dy = gg(t, y, params, Rt, Theta)
    phi = params.phi;
    Rc = params.Rc;
    eta = params.eta;
    g = params.g;
    Vb = params.Vb;
    rouc = params.rouc;

    % 使用 t 直接计算 Rt_integral
    Rt_integral = integral(@(t_var) Rt(t_var), 0, t);
    
    dy = zeros(2, 1);
    dy(1) = y(2);
    
    if y(1) <= -0.09
        if Theta(7) < (1 - phi) * Rc / (3 * phi * Vb)
            dy(2) = (1 - phi) * g - (5 * eta / (2 * Rc^2 * rouc) * y(2)) - (2 * phi * Rt_integral * Vb * g) / Rc;
        else
            y(1) = -0.09;
            y(2) = 0;
        end
    else
        dy(2) = (1 - phi) * g - (5 * eta / (2 * Rc^2 * rouc) * y(2)) - (2 * phi * Rt_integral * Vb * g) / Rc;
    end
end
