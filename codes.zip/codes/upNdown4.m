clc;
clear;
close all;

% 定义参数
pi_value = pi;
rouw = 1000;
rouc = 1200;
phi = rouw / rouc;
Rc = 0.01; % 半径
Rb = 0.0006; % 小球半径
eta = 1.1E-3;
g = 9.81; % 重力加速度
Vb = 4*pi*Rb^3/3; % 小球体积
S0 = 1.66;
Smc = 0.00001;
Tr = 7.231; % 7.231s
chi = 2.5;
lambda0 = 58.4;

% 时间范围
tspan = 600:0.1:1200;
y0 = [-0.09; 0]; % 初始条件：Theta(1) 和 Theta(2)初始化为 0

% 定义 Rt(t) 函数
Rt = @(t) 2.309E5*exp(-0.001617*t);

params.pi = pi_value;
params.rouw = rouw;
params.rouc = rouc;
params.phi = phi;
params.Rc = Rc;
params.eta = eta;
params.g = g;
params.Vb = Vb;
params.Rt = Rt;
params.tspan = tspan;
params.Vb = Vb;

% 使用ode45求解微分方程
[t, y] = ode45(@(t, y) f(t, y, params), tspan, y0);

% 计算 Rt 的时间积分
Rt_integral = cumtrapz(t, Rt(t));

% 绘制结果
figure;
subplot(2,1,1);
plot(t, y(:, 1), 'LineWidth', 2, 'DisplayName', 'Y'); % 使用 y(:, 1) 绘制第一个状态变量
xlabel('$t$/s','interpreter','latex')
ylabel('$y$/m','interpreter','latex')
set(gca, 'FontSize',9,'FontName','Times New Roman')
set(gcf,'unit','centimeters','position',[10,10,8.5,8.5/1.618])
xlim([600,620]);

subplot(2,1,2);
plot(t, Rt(t), 'LineWidth', 2);
xlabel('$t$/s','interpreter','latex')
ylabel('$\lambda /\rm{s/m^2}$','interpreter','latex')
set(gca, 'FontSize',9,'FontName','Times New Roman')
set(gcf,'unit','centimeters','position',[10,10,8.5,8.5/1.618])
xlim([600,650]);


grid on;
hold off;

% 定义微分方程的系统函数
function dy = f(t, y, params)
    pi_value = params.pi;
    rouw = params.rouw;
    rouc = params.rouc;
    phi = params.phi;
    Rc = params.Rc;
    eta = params.eta;
    g = params.g;
    Rt = params.Rt;
    tspan = params.tspan;
    Vb = params.Vb;

    % 找到对应当前时间 t 的索引
    [~, idx] = min(abs(tspan - t));

    if idx > 1
        % 数值积分 Rt 从 0 到 t 使用梯形规则
        Rt_integral = trapz(tspan(1:idx), Rt(tspan(1:idx)));
    else
        Rt_integral = 0; % 如果 idx 无效，将积分设置为零
    end

    dy = zeros(2, 1);
    dy(1) = y(2);
    dy(2) = (1-phi) * g - (9 * eta / (2 * Rc^2 * rouc) * y(2)) - (3 * phi * Rt_integral*Vb*g) / (Rc);
end
