clc;
clear;
close all;

% 定义常量
Mc = 0.001; % 巧克力的重量，KG
Rc = 0.005; % 一个巧克力的半径
Rb = 0.0005;
theta0 = 0.1; % 第一个气泡破裂的角度
thetab = 0.06; % 一个气泡所占角度
Sb = Rb^2; % 一个气泡的占地面积
Ic = (2/5) * Mc * Rc^2; % 巧克力转动惯量
s = 1; % 假设一个常数s
n = 4; % 气泡带的宽度
rouc = 1.2; % 巧克力浓度
rouw = 1; % 水的密度
% S0 = 1.66;
% Smc = 0.002;
Tr = 2172; % 36.2min=这么多秒
% chi = 2.5;
% lambda0 = 58.4;
Vb = 4*pi*Rb^3/3;
g = 9.81;
Fb = Vb * g; % 一个泡泡的力，N
Tb1 = -Fb * cosd(theta0) * Rc*5; % 第一个气泡的力矩（微扰大概的大小）
phi = rouw / rouc;
eta = 1.1E-3;%粘滞系数

% 将参数封装到结构体中
params.Tb1 = Tb1;
params.Ic = Ic;
params.Fb = Fb;
params.thetab = thetab;
params.Sb = Sb;
params.s = s;
params.theta0 = theta0;
params.n = n;
params.Rc = Rc;
params.rouc = rouc;
params.rouw = rouw;
params.g = g;
params.phi = phi;
params.eta = eta;
params.Vb = Vb;
params.Nthresh = 84;

% 定义初始条件
tspan = 0:0.01:10;  % 初始时间范围
Theta0 = [0; 0; 0; 0; 1; 10; 0; 0; 0]; 
% 1.Nbreak带来的theta break
% 2.Nbreak带来的角速度
% 3.Nnew 带来的Thetanew
% 4.Nnew带来的角速度
% 5.总的角位移
% 6.总的角速度
% 7.总的破裂量



% 定义 Rt 函数
Rt = @(t) 2.309E5 * exp(-0.001617 * t);
Rt_integral = cumtrapz(tspan, Rt(tspan)); % 计算Rt从0到t的积分

% 初始化 Theta 和 Nnet 变量
% Theta = Theta0;
% Nnet = [];



% 检查是否有足够的数据进行绘图
% 设置绝对和相对求解精度
options = odeset('RelTol', 1e-9, 'AbsTol', 1e-12, 'Events', @(t, Theta) events(t, Theta, params));
% 使用 ode45 求解微分方程
[t, Theta] = ode45(@(t, Theta) f(t, Theta, params, Rt_integral),tspan, Theta0, options);

    % 绘图
    figure;
    subplot(2, 1, 1);
    plot(tspan, Theta(:, 7), 'LineWidth', 2, 'DisplayName', 'Nnet');
    xlabel('Time (s)');
    ylabel('Nnet (个)');
    title('Nnet vs. Time');
    legend;
    grid on;
    %xlim([0, 1]);
    
    subplot(2, 1, 2);
    plot(tspan, Theta(:, 8), 'LineWidth', 2, 'DisplayName', 'y');
    xlabel('Time (s)');
    ylabel('y (m)');
    title('y vs. Time');
    legend;
    grid on;

% % 事件函数：检测 y(1) 何时达到 -0.09
% function [value, isterminal, direction] = event_y_reaches_threshold(~, y)
%     value = y(1) + 0.09;  % 事件条件
%     isterminal = 1;       % 事件发生时停止
%     direction = 0;       % 检测下降的方向,0是两边都可以的意思
% end

% Theta 方程的微分方程
function dThdt = f(~, Theta, params, Rt_integral)
    Tb1 = params.Tb1;
    Ic = params.Ic;
    Fb = params.Fb;
    thetab = params.thetab;
    Sb = params.Sb;
    Rc = params.Rc;
    n = params.n;
    s = params.s; % 使用 params.s 传递的 s 变量

    dThdt = zeros(9, 1); %初始化
   
    %Theta1对应Nbreak产生的角位移，Theta2对应其角速度
    %如果浸没物已经在液体顶端（-0.09m,取向下为正），才以转动的公式计算它，否则设其为0，因为这是转动不会导致气泡破裂
    dThdt(1) = Theta(2);
    if Theta(8) <= -0.09 
        dThdt(1) = 0;
    else
        dThdt(2) = Tb1 .* n ./ Ic + Fb .* n *Rc./ Ic * (sind((Theta(5) + thetab) ./ 2) * sind(Theta(5) ./ 2) ./ sind(thetab ./ 2));
    end
    
    %Theta3对应Nnew带来的角位移，Theta4为角速度。气泡不管在液面还是液面以下都会不断生成，所以不需要条件判断
    dThdt(3) = Theta(4); 
    dThdt(4) = squeeze(Fb*Rc / Ic * n * (-cosd(-thetab / 2 * (Rt_integral .* (Sb * (Theta(1) ./ Ic) ./ (1 + Rt_integral * Sb)))) - thetab + Theta(5)) ./ ...
               (2 * sind(-thetab ./ s)));
    %Theta5对应总的角位移，Theta6对应净角速度，Theta7是总的破裂的气泡数量（Nbreak-Nnew）
    dThdt(5) = Theta(6); 
    dThdt(7) = Theta(5) ./ thetab * (1 - Rt_integral * Sb ./ thetab ./ (1 + Rt_integral * Sb));
    
    %如果说总破裂量小于等于0，说明气泡已经布满了，那么新的气泡将不在生成，Nnew带来的角加速度dThdt(4)也就为0
    %反之净角加速度等于破裂和生成加速度相加
    if Theta(7) <= 0
        dThdt(4) = 0; % 气泡已经布满了
    else
        dThdt(6) = dThdt(2) + dThdt(4);
    end

    phi = params.phi;
    Rc = params.Rc;
    eta = params.eta;
    g = params.g;
    Vb = params.Vb;
    rouc = params.rouc;

    % 使用 t 直接计算 Rt_integral
    %Rt_integral = integral(@(t_var) Rt(t_var), 0, t);
    %初始化
    %Theta81是竖直方向位移，向下为正
    %Theta92书竖直方向速度，向下为正
    dThdt(8) = Theta(9);

    %如果浸没物已经在液面了，而且总破裂量少于Threshold（超过这个量气泡提供的浮力将无法支撑物体悬浮）， 那么y保持不变
    % 反之使用文中用到的公式计算
    %如果说没有在液面(213行始)，如果浸没物沉在底部且总气泡破裂量大于theshold，则纵向加速度为0
    %反之按照公式计算
    if Theta(8) <= -0.09 && Theta(7) < (1 - phi) * Rc / (3 * phi * Vb)
            % Theta(8) = -0.09;
            dThdt(8) = 0;
        elseif Theta(8) <= -0.09 && Theta(7) > (1 - phi) * Rc / (3 * phi * Vb)
           dThdt(9) = (1 - phi) * g - (5 * eta / (2 * Rc^2 * rouc) * Theta(9)) - (2 * phi * Rt_integral * Vb * g) / Rc;

        elseif Theta(8) <=0 && Theta(7)>(1 - phi) * Rc / (3 * phi * Vb)
            dThdt(9)=0;
        else
        dThdt(9) = (1 - phi) * g - (5 * eta / (2 * Rc^2 * rouc) *Theta(9)) - (2 * phi * Rt_integral * Vb * g) / Rc;
     end

end

