syms i j t s

Mc = 0.001; %巧克力的重量
Fb = 0.01; %一个泡泡的力
Rc = 0.025; %一个巧克力的半径
theta0 = 70; %第一个气泡破裂的角度
thetab = 0.0001;%一个气泡所占角度
Sb = 0.0001; %一个气泡的占地面积
Ic = (2/5)*Mc*Rc^2; %巧克力转动惯量


tmin = 0;
tmax = 1000;


Tb1 = -Fb*cos(theta0)*Rc; %第一个气泡的力矩
t1 = 1;
t2 = 100;%与tmin tmax区分开，是一个特定时间段


% 先定义 Nb 和 Tbreak 的关系
% 初始的力矩定义，Tbreak 依赖于 Nb，因此 Nb 的定义需要先于 Tbreak 进行
Nb(t) = str2sym('Nb(t)');
Tbreak = Tb1 + symsum(Fb*sin(i*thetab)*Rc, i, 1, Nb(t));%net力矩的定义
%nb = @(t,t) Tbreak/Tc;


alpha = Tbreak /Ic;%角加速度
% 计算角度的变化，现在开始定义 Nb
omega = int(alpha, t, t1, t2);
Theta = int(omega, t, t1, t2);
Nb(t) = Theta / thetab;
% 重新计算 Tbreak
Tbreak = Tb1 + symsum(Fb * sin(i * thetab) * Rc, i, 1, Nb(t));


R(t, s) = 2*s^t; %乱定义的成核率公式

Sa = (Nb(t)*Sb)/(1+int(R,t,t1,t2)*Sb);%available area的定义
f = @(s,t) R;
smin = 0;
smax = Sa;
N2 = int(R,t,t1,t2);
Nnew = int(N2,s,smin,smax);% 新生成气泡的个数
Tnew = symsum(-Fb * sind(Theta - j * thetab), j, 1, Nnew); %使用Nnew(t1)是不可取的，

Ntotal = Nb(t) - Nnew;

Ttotal = Tbreal - Tnew; %合力矩
NetAlpha = Ttotal/Tc;

time_vals = kinspace(tmin, tmax, 100); %时间范围
Ntotal_vals = assayfun(@(t)double(subs(Ntotal, t)), time_vals); %计算ntotal在每个时间点的值

figure;
plot (time_vals, Ntotal_vals, 'LineWidth',2);
xlabel('Time');
ylabel('Ntotal');
title ('Ntot vs. time');
grid on;
