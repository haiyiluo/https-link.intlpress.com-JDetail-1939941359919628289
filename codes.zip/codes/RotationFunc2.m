syms i j t s

Mc = 0.001; % 巧克力的重量，KG
Fb = 0.0001; % 一个泡泡的力，N
Rc = 0.005; % 一个巧克力的半径
theta0 = 1.22; % 第一个气泡破裂的角度
thetab = 0.06; % 一个气泡所占角度
Sb = 0.0000001; % 一个气泡的占地面积
Ic = (2/5) * Mc * Rc^2; % 巧克力转动惯量

tmin = 0;
tmax = 10;

Tb1 = -Fb * cosd(theta0) * Rc; % 第一个气泡的力矩
%t1 = 0;
%t2 = 10; % 与 tmin tmax 区分开，是一个特定时间段


% 定义 Nb 和 Tbreak 的关系
syms Nb_sym(t)
Tbreak = Tb1 + symsum(Fb * sin(i * thetab) * Rc, i, 1, Nb_sym(t)); % net力矩的定义

alpha = Tbreak / Ic; % 角加速度
% 计算角速度和角度的变化
omega = int(alpha, t);
Theta = int(omega, t);
Nb_expr = Theta / thetab;

% 重新计算 Tbreak
Tbreak = Tb1 + symsum(Fb * sin(i * thetab) * Rc, i, 1, Nb_expr);

% 定义成核率
R =1;

% 定义 available area
Sa_expr = (Nb_expr * Sb) / (1 + int(R, t) * Sb);

% 计算新生成气泡的个数
N2 = int(R, t);
Nnew_expr = int(N2, s, 0, Sa_expr);

% 计算新的力矩
Tnew_expr = symsum(-Fb * sind(Theta - j * thetab), j, 1, Nnew_expr);

% 计算总气泡数和总力矩
Ntotal_expr = Nb_expr - Nnew_expr;
Ttotal_expr = Tbreak - Tnew_expr;
NetAlpha_expr = Ttotal_expr / Ic;

% 定义时间范围
time_vals = linspace(tmin, tmax, 0.01);

% 初始化 Ntotal_vals 数组
Ntotal_vals = zeros(size(time_vals));

% 逐步计算每个时间点的 Ntotal 值
for k = 1:length(time_vals)
    t_val = time_vals(k);
    Nb_val = double(subs(Nb_expr, t, t_val));
    Sa_val = double(subs(Sa_expr, t, t_val));
    Nnew_val = double(subs(Nnew_expr, t, t_val));
    Ntotal_vals(k) = double(subs(Ntotal_expr, t, t_val));
end

% 绘制结果
figure;
plot(time_vals, Ntotal_vals, 'LineWidth', 2);
xlabel('Time');
ylabel('Ntotal');
title('Ntotal vs. time');
grid on;
