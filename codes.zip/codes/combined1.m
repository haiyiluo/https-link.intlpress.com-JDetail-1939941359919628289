clc;
clear;
close all;

% 定义常量
Mc = 0.001; % 巧克力的重量，KG
Rc = 0.005; % 一个巧克力的半径
Rb = 0.0005;
theta0 = 0.1; % 第一个气泡破裂的角度
thetab = 0.06; % 一个气泡所占角度
Sb = Rb^2; % 一个气泡的占地面积
Ic = (2/5) * Mc * Rc^2; % 巧克力转动惯量
s = 1; % 假设一个常数s
n = 4; % 气泡带的宽度
rouc = 1.2; % 巧克力浓度
rouw = 1; % 水的密度
S0 = 1.66;
Smc = 0.002;
Tr = 2172; % 36.2min=这么多秒
chi = 2.5;
lambda0 = 58.4;
Vb = 4*pi*Rb^3/3;
g = 9.81;
Fb = Vb * g; % 一个泡泡的力，N
Tb1 = -Fb * cosd(theta0) * Rc; % 第一个气泡的力矩
pi = 3.14159265;
phi = rouw / rouc;
eta = 1.1E-3;

% 将参数封装到结构体中
params.Tb1 = Tb1;
params.Ic = Ic;
params.Fb = Fb;
params.thetab = thetab;
params.Sb = Sb;
params.s = s;
params.theta0 = theta0;
params.n = n;
params.Rc = Rc;
params.rouc = rouc;
params.rouw = rouw;
params.g = g;
params.pi = pi;
params.phi = phi;
params.eta = eta;
params.Vb = Vb;

% 计算 Nthresh 并添加到 params 结构体中
params.Nthresh = 84;

% 定义初始条件
tspan = [0, 100];  % 初始时间范围
y0 = [0; 0]; % 初始化 y 的初值
Theta0 = [0; 0; 0; 0; 100; 1; 0]; % 初始条件：Theta(1)到Theta(6)都初始化为0

% 定义 Rt 函数
Rt = @(t) 2.309E5 * exp(-0.001617 * t);

% 设置求解器选项，添加事件检测
options_gg = odeset('RelTol', 1e-9, 'AbsTol', 1e-12, 'Events', @(t, y) event_y_reaches_threshold(t, y));

% 第一步：求解 y 的微分方程
[t_y, y, te, ye, ie] = ode45(@(t, y) gg(t, y, params, Rt, Theta0), tspan, y0, options_gg);

% 初始化 Theta 和 Nnet 变量
Theta = []
Nnet = []

% 如果 te 不为空，表示事件发生
if ~isempty(te)
    tspan_theta = [te, tspan(2)];
    Rt_int = cumtrapz(t_y, Rt(t_y));

    % 第二步：使用 ode45 求解 Theta 的微分方程
    [t_theta, Theta] = ode45(@(t, Theta) f(t, Theta, params, Rt_int, t_y, y), tspan_theta, Theta0);

    Rt_interp = interp1(t_y, Rt_int, t_theta);

    % if ye(1) > -0.09
    %     Nnet = -Rt_int;
    % else
    Nnet = Theta(:, 5) / params.thetab .* (1 - Rt_interp .* params.Sb / params.thetab ./ (1 + Rt_interp .* params.Sb));
    % end

    t = [t_y; t_theta];
    combined_Theta = [zeros(length(t_y), size(Theta, 2)); Theta];
    y_combined = [y; interp1(t_y, y, t_theta, 'linear', 'extrap')];
else
    t = t_y;
    combined_Theta = zeros(length(t_y), length(Theta0));
    y_combined = y;
end
 
% 检查计算结果并绘图
disp('t:');
disp(t);
disp('Theta:');
disp(combined_Theta);
disp('Nnet:');
disp(Nnet);

figure;
subplot(2, 1, 1)
plot(t, combined_Theta(:, 5), 'LineWidth', 2, 'DisplayName', 'Nnet');
xlabel('Time (s)');
ylabel('Nnet (个)');
title('Nnet vs. Time');
legend;
grid on;
xlim([0, 100]);

subplot(2, 1, 2);
plot(t, y_combined(:, 1), 'LineWidth', 2, 'DisplayName', 'y');
xlabel('Time (s)');
ylabel('y (m)');
title('y vs. Time');
legend;
grid on;

% 事件函数：检测 y(1) 何时达到 -0.09
function [value, isterminal, direction] = event_y_reaches_threshold(~, y)
    value = y(1) + 0.09;  % 事件条件
    isterminal = 1;       % 事件发生时停止
    direction = -1;       % 检测下降的方向
end

% Theta 方程的微分方程
function dThdt = f(t, Theta, params, Rt_int, t_y, y)
    Tb1 = params.Tb1;
    Ic = params.Ic;
    Fb = params.Fb;
    thetab = params.thetab;
    Sb = params.Sb;
    s = params.s;
    theta0 = params.theta0;
    n = params.n;
    Rc = params.Rc;
    rouc = params.rouc;
    rouw = params.rouw;
    
    % 插值计算 Rt_int
    R_integral = interp1(t_y, Rt_int, t, 'linear', 'extrap');
    
    dThdt = zeros(7, 1); 
    dThdt(1) = Theta(2);
    if y(:,1) <=- 0.09
      Theta(2)=0;
    else
      dThdt(2) = Tb1 * n / Ic + Fb * n / Ic * (sind((Theta(5) + thetab) / 2) * sind(Theta(5) / 2) / sind(thetab / 2));
    end
    dThdt(3) = Theta(4); 
    dThdt(4) = Fb / Ic * n * (-cosd(-thetab / 2 * (R_integral .* (Sb * (Theta(1) / Ic) / (1 + R_integral * Sb)))) - thetab + Theta(5)) / ...
               (2 * sind(-thetab / s));       
    dThdt(5) = Theta(6); 
    dThdt(7) = Theta(5) / thetab * (1 - R_integral * Sb / thetab ./ (1 + R_integral * Sb));
 
    if Theta(7) < 0
        dThdt(6) = 0;%气泡已经布满了
    else
        dThdt(6) = dThdt(2) + dThdt(4);
    end

end

function [value, isterminal, direction] = events(~, Theta, params)
    b = params.b;
    Nthresh = params.Nthresh;
    % 定义事件函数
    Ntot = Theta(7);
    if Ntot>=84
        b=0;
    end 
    value = [b, Ntot];% 当 Ntot 达到 Nthresh 或者小于 0 时触发事件
    isterminal = [1,1]; % 停止积分
    direction = [0,-1]; % 触发方向为任意方向
    
end



% y 方程的微分方程
% 修改 gg 函数：移除 t_y
function dy = gg(t, y, params, Rt, Theta)
    pi_value = params.pi;
    rouw = params.rouw;
    rouc = params.rouc;
    phi = params.phi;
    Rc = params.Rc;
    eta = params.eta;
    g = params.g;
    Vb = params.Vb;

    % 使用 t 直接计算 Rt_integral
    Rt_integral = integral(@(t_var) Rt(t_var), 0, t);
    y(1)
    dy = zeros(2, 1);
    dy(1) = y(2);
    if y(1) <= -0.09
        if Theta(7) < (1 - phi) * Rc / (3 * phi * Vb)
            dy(2) = (1 - phi) * g - (5 * eta / (2 * Rc^2 * rouc) * y(2)) - (2 * phi * Rt_integral * Vb * g) / Rc;
        else
            y(1) = -0.09;
            y(2) = 0;
        end
    else
        dy(2) = (1 - phi) * g - (5 * eta / (2 * Rc^2 * rouc) * y(2)) - (2 * phi * Rt_integral * Vb * g) / Rc;
    end
end