

Mc = 0.001; % 巧克力的重量，KG
Fb = 0.0001; % 一个泡泡的力，N
Rc = 0.005; % 一个巧克力的半径
theta0 = 1.22; % 第一个气泡破裂的角度
thetab = 0.06; % 一个气泡所占角度
Sb = 0.0000001; % 一个气泡的占地面积
Ic = (2/5) * Mc * Rc^2; % 巧克力转动惯量

tmin = 0;
tmax = 1000;

Tb1 = -Fb * cosd(theta0) * Rc; % 第一个气泡的力矩

% 定义 Nb 和 Tbreak 的关系

ode= diff(Theta,t,2)== Tb1/Ic + Fb/Ic*(sind((Theta ./ thetab + 1) * thetab ./ 2) * sind(Theta ./ thetab * thetab ./ 2) ./ sind(thetab ./ 2));
%alpha = Tbreak ./ Ic;
%Nb_expr = Theta ./ thetab;
% 定义微分方程
%ode = diff(Theta, t, 2) == alpha; % 角加速度的微分方程

% 通过解微分方程得到 Theta
ThetaSol(t) = dsolve(ode);
Nb_expr = ThetaSol/thetab;
% 定义成核率
R = 1;

% 定义 available area
Sa_expr = (Nb_expr * Sb) ./ (1 + int(R, t) * Sb);

% 计算新生成气泡的个数
N2 = int(R, t);
Nnew_expr = int(N2, s, 0, Sa_expr);

% 计算新的力矩
Tnew_expr = -Fb*(cosd(((-thetab ./ 2) * (Nnew_expr - 0) - thetab + theta0) ./ s * sind(-thetab / 2)));

% 计算总气泡数和总力矩
Ntotal_expr = Nb_expr - Nnew_expr;
Ttotal_expr = Tbreak - Tnew_expr;
NetAlpha_expr = Ttotal_expr ./ Ic;

% 定义时间范围
time_vals = linspace(tmin, tmax, 100);

% 初始化 Ntotal_vals 数组
Ntotal_vals = zeros(size(time_vals));

% 逐步计算每个时间点的 Ntotal 值
for k = 1:length(time_vals)
    t_val = time_vals(k);

    % 计算 Theta_val
    Theta_val = double(subs(ThetaSol, t, t_val));
    
    % 确保替换 Nb_expr 中的符号变量
    Nb_val = double(subs(Nb_expr, Theta, Theta_val));
    
    % 确保替换 Tbreak 中的符号变量
    %Tbreak_val = double(subs(Tbreak, Theta, Theta_val));
    
    % 确保替换 Sa_expr 中的符号变量
    Sa_val = double (subs(subs(Sa_expr, Theta, Theta_val), Nb_expr, Nb_val));
    
    % 确保替换 N2 中的符号变量
    N2_val = double(subs(N2, t, t_val));
    
    % 确保替换 Nnew_expr 中的符号变量
    Nnew_val = double(subs(subs(Nnew_expr, Theta, Theta_val), {t, s}, {t_val, Sa_val}));
    
    % 确保替换 Tnew_expr 中的符号变量
    Tnew_val = double(subs(subs(Tnew_expr, Theta, Theta_val), {t, s}, {t_val, Nnew_val}));
    
    % 确保替换 Ntotal_expr 中的符号变量
    Ntotal_vals(k) = double(subs(subs(Ntotal_expr, Theta, Theta_val), {t, s}, {t_val, Sa_val}));
end

% 绘制结果
figure;
plot(time_vals, Ntotal_vals, 'LineWidth', 2);
xlabel('Time');
ylabel('Ntotal');
title('Ntotal vs. time');
grid on;
